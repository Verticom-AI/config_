from django.contrib import admin
from .models import Prescript

admin.site.register(Prescript)