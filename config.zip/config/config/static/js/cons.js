document.addEventListener("DOMContentLoaded", function () {
    AOS.init({
        duration: 800, // مدت زمان انیمیشن (به میلی‌ثانیه)
        once: true, // انیمیشن فقط یک بار اجرا شود
    });
});
