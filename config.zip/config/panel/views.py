from django.shortcuts import render, get_list_or_404
from ticket import models as ticket_models
from store import models as store_models
def consultations(request):
    products= store_models.Product.objects.all()
    tickets = ticket_models.Ticket.objects.filter(status=0)
    print(len(tickets))
    context = {
        'products': products,
        'tickets' : tickets,

    }
    return render(request, 'panel/admin-consultation.html', context=context)
