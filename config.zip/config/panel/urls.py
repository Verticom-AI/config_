from django.urls import path
from panel import views
urlpatterns = [
    path('consultations', views.consultations),
]