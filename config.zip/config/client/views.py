from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from .forms import UserRegistrationForm, LoginForm
from .models import User
from ticket.models import Message

import os
from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings


def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'client/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            mobile_number = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, mobile_number=mobile_number, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = LoginForm()
    return render(request, 'client/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

