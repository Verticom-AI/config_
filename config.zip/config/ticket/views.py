from django.shortcuts import render, get_object_or_404, get_list_or_404
from . import models
from client.models import User
import os, time
from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings

# Create your views here.
def consultations(request):
    model = models.Ticket_subject
    objs = get_list_or_404(model)
    context = {
        'objs': objs,

    }
    return render(request, 'ticket/consultations.html', context=context)

def consultation(request, id):
    model = models.Ticket_subject
    obj = get_object_or_404(model, id=id)
    context = {
        'obj': obj,
    }
    return render(request, 'ticket/consultation.html', context=context)

def consultation_request(request, id):
    model = models.Ticket_subject
    obj = get_object_or_404(model, id=id)
    context = {
        'obj': obj,
    }
    if request.method == 'POST':
        msg     = request.POST.get('msg')
        sender      = get_object_or_404(User, pk=request.user.id)
        receiver    = get_object_or_404(User, pk=request.user.id)
        subject     = obj
        msg_obj= models.Message(sender=sender, receiver=receiver, content=msg)
        msg_obj.save()
        ticket_obj  = models.Ticket.objects.create(client=sender, subject=subject,)
        ticket_obj.messages.add(msg_obj)
        img_file = request.FILES.getlist('file')
        print(img_file)
        if img_file:
            for a in img_file:
                                # Save the file to the media directory
                audio_path = os.path.join(settings.MEDIA_ROOT, 'consultation/img', str(time.time())+'.jpg')
                os.makedirs(os.path.dirname(audio_path), exist_ok=True)
                with open(audio_path, 'wb+') as destination:
                    for chunk in a.chunks():
                        destination.write(chunk)
                msg_obj= models.Message(sender=sender, receiver=receiver, media_content=audio_path)
                msg_obj.save()
                ticket_obj.messages.add(msg_obj)
        audio_file = request.FILES.getlist('audio_file')
        print(audio_file)
        if audio_file:
            for a in audio_file:
                                # Save the file to the media directory
                audio_path = os.path.join(settings.MEDIA_ROOT, 'consultation/audio', str(time.time())+'.mp3')
                os.makedirs(os.path.dirname(audio_path), exist_ok=True)
                with open(audio_path, 'wb+') as destination:
                    for chunk in a.chunks():
                        destination.write(chunk)
                msg_obj= models.Message(sender=sender, receiver=receiver, media_content=audio_path)
                msg_obj.save()
                ticket_obj.messages.add(msg_obj)
        ticket_obj.save()
        return HttpResponse("OK sent, wait for responses")
    return render(request, 'client/private-consultation.html')