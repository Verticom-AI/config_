from django.urls import path
from ticket import views
urlpatterns = [
    path('', views.consultations, name='consultations'),
    path('<int:id>', views.consultation, name='consultation'),
    path('request/<int:id>', views.consultation_request, name=''),
]